# template-simple
A simplest demo of IGM template
