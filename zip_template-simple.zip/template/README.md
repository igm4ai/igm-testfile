# hello world for {{ user.name }}

This is a hello world project of igm created by {{ user.name | potc }} (age: `{{ user.age }}`).

You can start this project by the following command:

```python
python main.py
```
